# Adapted from existing Docker image
[![Docker Pulls](https://img.shields.io/docker/pulls/strm/tor-hiddenservice-nginx.svg?style=plastic)](https://hub.docker.com/r/strm/tor-hiddenservice-nginx/)
![License](https://img.shields.io/badge/License-GPL-blue.svg?style=plastic)


# Generate 10 credentials for onion services
```
./generate_v3_onion_address.sh 10
```