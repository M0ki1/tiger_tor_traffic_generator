#!/bin/sh
exec autoconf -f
