int cpucount(void);
